import { Component, OnInit } from '@angular/core';
import { MainCourseFoodService } from '../services/main-course-food.service';
import { Food } from '../shared/food';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-main-course-food',
  templateUrl: './main-course-food.component.html',
  styleUrls: ['./main-course-food.component.css']
})
export class MainCourseFoodComponent implements OnInit {

  foodList: Array<Food> = [];
  foodData: any;

  constructor(private _maincoursefoodService: MainCourseFoodService) { }

  ngOnInit(): void {
    this._maincoursefoodService.getmain_course().subscribe(result => {
      this.foodList = result;
    }, (error) => {
      console.log(error);
    })
  }
  getmain_course() {
    this._maincoursefoodService.getmain_course().subscribe(result => { this.foodList = result })
  }

  deletefoodList(food: any) {
    this._maincoursefoodService.deletemain_course(food.id).subscribe(result => {
      alert("Food :  " + food.fname + " \n deleted from the records");
      this.getmain_course();
    })
  }


}
