import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainCourseFoodComponent } from './main-course-food.component';

describe('MainCourseFoodComponent', () => {
  let component: MainCourseFoodComponent;
  let fixture: ComponentFixture<MainCourseFoodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainCourseFoodComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCourseFoodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
