import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopHereComponent } from './shop-here.component';

describe('ShopHereComponent', () => {
  let component: ShopHereComponent;
  let fixture: ComponentFixture<ShopHereComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShopHereComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShopHereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
