import { Component, OnInit } from '@angular/core';
import { MainCourseFoodService } from '../services/main-course-food.service';
import { Food } from '../shared/food';

@Component({
  selector: 'app-shop-here',
  templateUrl: './shop-here.component.html',
  styleUrls: ['./shop-here.component.css']
})
export class ShopHereComponent implements OnInit {
  foodLists: any;
  fn?: string;
  pr?: number;
  total_bill: number = 0;
  array = [] as any;

  constructor(private _maincoursefoodService: MainCourseFoodService) { }

  ngOnInit(): void {
    this.getFoodLists();
  }
  getFoodLists() {
    this._maincoursefoodService.getmain_course().subscribe(result => { this.foodLists = result })
  }

  FoodCart(fname: string, price: number) {
    this.pr = 0;
    this.fn = "";

    this.fn = fname;
    this.pr = price;
    this.array.push({ "fname": this.fn, "price": this.pr });


    this.total_bill += Number(this.pr);
  }

}






