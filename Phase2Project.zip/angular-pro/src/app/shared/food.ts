export class Food {
    id!: number;
    fname!: string;
    price!: number;
    img_url!: string;
    quan!: number;
}
