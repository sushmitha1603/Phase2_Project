export class User {
    email?: string;
    password?: string;
    cred?: string;
}
