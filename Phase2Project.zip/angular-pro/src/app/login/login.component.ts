import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../shared/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  submitted: boolean = false;

  user: User = new User();
  loginform!: FormGroup;


  constructor(private _formBuilder: FormBuilder, private _router: Router) { }
  ngOnInit(): void {
    this.loginform = this._formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    })
  }

  get f() {
    return this.loginform.controls;
  }
  login() {
    this.submitted = true;
    if (this.loginform.invalid) {
      return;
    }
    if (this.user.email == "admin@gmail.com" && this.user.password == "admin") {
      alert('logged in successfully');
      this._router.navigateByUrl('/food_catalog');
    }
    else {
      alert('Invalid credentials');
    }

  }


}


