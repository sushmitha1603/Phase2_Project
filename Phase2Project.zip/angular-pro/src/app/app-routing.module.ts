import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckoutComponent } from './checkout/checkout.component';
import { FooditemCatalogComponent } from './fooditem-catalog/fooditem-catalog.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { MainCourseFoodAddComponent } from './main-course-food-add/main-course-food-add.component';
import { MainCourseFoodComponent } from './main-course-food/main-course-food.component';
import { ShopHereComponent } from './shop-here/shop-here.component';


const routes: Routes = [
  { path: 'home', component: HomepageComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },// setting default route to login page
  { path: 'login', component: LoginComponent },
  { path: 'food_catalog', component: FooditemCatalogComponent },
  { path: 'main_course', component: MainCourseFoodComponent },
  { path: 'main_course_add', component: MainCourseFoodAddComponent },
  { path: 'shop_here', component: ShopHereComponent },
  { path: 'checkout', component: CheckoutComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
