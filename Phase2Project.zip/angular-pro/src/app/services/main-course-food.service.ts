import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Food } from '../shared/food';
import { Observable } from 'rxjs';
@Injectable()
export class MainCourseFoodService {

  constructor(private _http: HttpClient) { }

  getmain_course(): Observable<Food[]> {
    return this._http.get<Food[]>('http://localhost:3000/food');
  }
  addgetmain_course(fooditems: Food) {  //object sent
    return this._http.post('http://localhost:3000/food', fooditems);
  }
  deletemain_course(id: number): Observable<Food> {
    return this._http.delete<Food>('http://localhost:3000/food/' + id);
  }
}
