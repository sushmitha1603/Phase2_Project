import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooditemCatalogComponent } from './fooditem-catalog.component';

describe('FooditemCatalogComponent', () => {
  let component: FooditemCatalogComponent;
  let fixture: ComponentFixture<FooditemCatalogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FooditemCatalogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooditemCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
