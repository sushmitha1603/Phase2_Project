import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fooditem-catalog',
  templateUrl: './fooditem-catalog.component.html',
  styleUrls: ['./fooditem-catalog.component.css']
})
export class FooditemCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
