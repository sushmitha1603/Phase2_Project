import { Component, OnInit } from '@angular/core';
import { MainCourseFoodComponent } from '../main-course-food/main-course-food.component';
import { MainCourseFoodService } from '../services/main-course-food.service';
import { Food } from '../shared/food';
import { Router } from '@angular/router';
@Component({
  selector: 'app-main-course-food-add',
  templateUrl: './main-course-food-add.component.html',
  styleUrls: ['./main-course-food-add.component.css']
})
export class MainCourseFoodAddComponent implements OnInit {

  food: Food = new Food();
  constructor(private _maincoursefoodService: MainCourseFoodService,
    private _router: Router) { }

  ngOnInit(): void { }
  addfood() {
    this._maincoursefoodService.addgetmain_course(this.food).subscribe(result => {
      alert('Food iteam added sucessfully');
      this._router.navigate(['/main_course']);
    }, error => {
      console.log(error);

    })

  }
}
