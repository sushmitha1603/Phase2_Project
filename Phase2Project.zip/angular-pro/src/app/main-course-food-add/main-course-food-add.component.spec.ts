import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainCourseFoodAddComponent } from './main-course-food-add.component';

describe('MainCourseFoodAddComponent', () => {
  let component: MainCourseFoodAddComponent;
  let fixture: ComponentFixture<MainCourseFoodAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainCourseFoodAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCourseFoodAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
